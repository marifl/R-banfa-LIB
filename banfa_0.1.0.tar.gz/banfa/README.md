# banfa

Simple R Project Creation and Management

## Installation

You can install the development version of banfa from GitHub:

```r
# install.packages("devtools")
devtools::install_github("yourusername/banfa")
```

### Installing the CLI

After installing the package, you can make the `rprj` command available system-wide:

```bash
# Find where the CLI is installed
R -e "cat(system.file('bin/rprj', package='banfa'))"

# Add to your PATH (example for bash/zsh)
echo 'export PATH="$PATH:$(R -e "cat(system.file(\"bin\", package=\"banfa\"))" -s)"' >> ~/.bashrc
# or for zsh
echo 'export PATH="$PATH:$(R -e "cat(system.file(\"bin\", package=\"banfa\"))" -s)"' >> ~/.zshrc

# Reload your shell configuration
source ~/.bashrc  # or source ~/.zshrc
```

## Usage

### Command Line Interface (CLI)

```bash
# Create a project in current directory
rprj init

# Create a project with a name
rprj init my_project

# Use a specific template
rprj init my_app --template shiny_app

# Create in specific directory
rprj init --path ~/projects/new_project

# List available templates
rprj list-templates

# Add a custom template
rprj add-template my_template --file existing_project.Rproj
```

### R Functions

The main function is `prj_init()` which creates a new R project with a `.Rproj` file:

```r
library(banfa)

# Create a project in the current directory
prj_init()

# Create a project with a specific name
prj_init(name = "my_analysis")

# Create a project in a specific directory
prj_init(path = "~/projects/new_project", name = "awesome_project")

# Use a different template
prj_init(template = "shiny_app")

# List available templates
prj_list_templates()
```

## Templates

banfa comes with several built-in templates:

- **default**: Standard R project settings
- **package**: Settings optimized for R package development
- **shiny_app**: Settings for Shiny applications

You can also add your own custom templates:

```r
# Add a template from an existing .Rproj file
prj_add_template("my_template", file = "path/to/existing.Rproj")

# Create a template with specific content
content <- c(
  "Version: 1.0",
  "",
  "RestoreWorkspace: No",
  "SaveWorkspace: No",
  "AlwaysSaveHistory: No",
  "",
  "EnableCodeIndexing: Yes"
)
prj_add_template("minimal", content = content)
```

## License

MIT