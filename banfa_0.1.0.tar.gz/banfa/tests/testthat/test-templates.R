test_that("prj_add_template creates template file", {
  # Create temporary template directory
  temp_dir <- tempdir()
  old_home <- Sys.getenv("HOME")
  Sys.setenv(HOME = temp_dir)
  
  tryCatch({
    # Create template content
    content <- c(
      "Version: 1.0",
      "",
      "RestoreWorkspace: No",
      "SaveWorkspace: No"
    )
    
    # Add template
    result <- prj_add_template("test_template", content = content)
    
    # Check that template file was created
    expect_true(file.exists(result))
    
    # Check content
    saved_content <- readLines(result)
    expect_equal(saved_content, content)
    
    # List templates should include the new one
    templates <- prj_list_templates()
    expect_true(any(grepl("test_template", templates)))
    
    # Clean up
    unlink(dirname(result), recursive = TRUE)
  }, finally = {
    Sys.setenv(HOME = old_home)
  })
})

test_that("load_template finds package templates", {
  skip_if_not_installed("banfa")
  
  # Should find default template
  expect_no_error({
    template <- load_template("default")
  })
  
  # Should error on non-existent template
  expect_error(
    load_template("non_existent_template"),
    "Template 'non_existent_template' not found"
  )
})

test_that("prj_init creates projects with different templates", {
  skip_if_not_installed("banfa")
  
  temp_dir <- tempdir()
  
  # Test with package template
  pkg_proj <- file.path(temp_dir, "pkg_project")
  result <- prj_init(path = pkg_proj, template = "package")
  
  expect_true(file.exists(result))
  content <- readLines(result)
  expect_true(any(grepl("BuildType: Package", content)))
  
  # Clean up
  unlink(pkg_proj, recursive = TRUE)
  
  # Test with shiny template
  shiny_proj <- file.path(temp_dir, "shiny_project")
  result <- prj_init(path = shiny_proj, template = "shiny_app")
  
  expect_true(file.exists(result))
  content <- readLines(result)
  expect_true(any(grepl("QuitChildProcessesOnExit: Yes", content)))
  
  # Clean up
  unlink(shiny_proj, recursive = TRUE)
})