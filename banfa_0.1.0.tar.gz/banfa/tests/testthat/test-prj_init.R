test_that("prj_init creates project file", {
  skip_if_not_installed("banfa")
  
  # Create temporary directory
  temp_dir <- tempdir()
  test_proj <- file.path(temp_dir, "test_project")
  
  # Initialize project
  result <- prj_init(path = test_proj, name = "test_proj")
  
  # Check that .Rproj file was created
  expect_true(file.exists(result))
  expect_equal(basename(result), "test_proj.Rproj")
  
  # Clean up
  unlink(test_proj, recursive = TRUE)
})

test_that("prj_init uses current directory when path is NULL", {
  skip_if_not_installed("banfa")
  
  # Create temporary directory and set as working directory
  temp_dir <- tempdir()
  old_wd <- getwd()
  setwd(temp_dir)
  
  tryCatch({
    # Initialize project in current directory
    result <- prj_init(name = "current_dir_proj")
    
    # Check that .Rproj file was created in current directory
    expect_true(file.exists("current_dir_proj.Rproj"))
    
    # Clean up
    unlink("current_dir_proj.Rproj")
  }, finally = {
    setwd(old_wd)
  })
})

test_that("prj_list_templates returns character vector", {
  skip_if_not_installed("banfa")
  
  templates <- prj_list_templates()
  expect_type(templates, "character")
  expect_true("default" %in% templates)
})