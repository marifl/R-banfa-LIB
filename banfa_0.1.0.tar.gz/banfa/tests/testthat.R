library(testthat)
library(banfa)

test_check("banfa")